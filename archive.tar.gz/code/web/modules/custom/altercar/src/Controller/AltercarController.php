<?php
/**
 * @file
 * Contains \Drupal\altercar\Controller\AltercarController.
 */
namespace Drupal\altercar\Controller;

use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;


class AltercarController {
  public function content() {
  
  $current_user = \Drupal::currentUser();
  $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
  $user_car = $user->get('field_user_car')->getValue();
  
  $roles = $current_user->getRoles();


  $uid = $current_user->id();

  if (in_array('authenticated', $roles)) {
    return array(
//      '#type' => 'markup',
      '#markup' => t('Num of users cars = '. sizeof($user_car) .''),
    );
    }
    else{
      throw new AccessDeniedHttpException();
    }
  }
}
